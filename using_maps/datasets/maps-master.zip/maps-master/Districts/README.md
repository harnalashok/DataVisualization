India - District Map
====

Districts of India, based upon the following sources:
 
 1. Taluk Boundaries available from [GeoCommons](http://geocommons.com/maps/249762) & Some taluk data downloaded from Bhuvan's Geoserver 2 years ago.
 2. The External Boundary of India was derived from the PC 2014 shapefile in this repository
 3. Names and extent were derived from the [Administrative Atlas of India](http://www.censusindia.gov.in/2011census/maps/administrative_maps/Final%20Atlas%20India%202011.pdf), Census of India 

**License**

The dataset is shared under [Creative Commons Attribution 2.5 India](http://creativecommons.org/licenses/by/2.5/in/) license.